---
name: ast-grep
description: This skill should be used when performing structural code search, transformation, or pattern-based code quality enforcement. Use this skill for tasks like finding code patterns, making mechanical refactors, creating linting rules, or searching for AST-level code structures that text-based tools like grep cannot handle.
---

# ast-grep

## Overview

ast-grep is a structural code search and transformation tool that understands code through Abstract Syntax Tree (AST) pattern matching. Unlike text-based tools like grep or sed, ast-grep understands code structure, making it reliable for refactoring and code quality enforcement.

**Use ast-grep for:**
- Finding complex code patterns (e.g., "all function calls with specific arguments")
- Making mechanical code transformations (e.g., renaming functions, changing APIs)
- Creating code quality rules (conformance rules, hints)
- Searching for syntactic patterns that text-based search misses

**Do NOT use ast-grep for:**
- Simple text search (use grep instead)
- Searching in comments or strings (use grep instead)
- Non-code files (use grep or other text tools)

## Quick Start

### Basic Pattern Search

Search for code patterns using `-p` (pattern) and `-l` (language):

```bash
# Find all calls to a specific function
ast-grep -p 'my_function($$$)' -l python src/

# Find method calls on any object
ast-grep -p '$OBJ.save($$$)' -l python .

# Find variable assignments
ast-grep -p '$VAR = $VALUE' -l python src/
```

### Basic Transformation

Replace code patterns using `-r` (replace) with `-U` (update):

```bash
# Rename a function
ast-grep -U -p 'old_function($$$ARGS)' -r 'new_function($$$ARGS)' .

# Change API call style
ast-grep -U -p 'mymodule.method($OBJ, $$$ARGS)' -r '$OBJ.method($$$ARGS)' .
```

**Always test without `-U` first** to preview matches before applying changes.

### Metavariables Quick Reference

- `$VAR` - Matches a single AST node (use UPPERCASE)
- `$$$ARGS` - Matches zero or more nodes (ellipsis)
- `$_` - Anonymous match (match but don't capture)

## Searching Code

### Simple Pattern Search

For straightforward searches, use the `-p` pattern flag:

```bash
# Find all async function definitions
ast-grep -p 'async def $FUNC($$$): $$$' -l python src/

# Find all requests.get() calls
ast-grep -p 'requests.get($$$)' -l python .

# Find imports from specific module
ast-grep -p 'from mymodule import $NAME' -l python .
```

### Complex Pattern Search

For searches requiring conditions, use `--inline-rules`:

```bash
# Find requests.get() calls WITHOUT timeout argument
ast-grep --inline-rules '
id: find-no-timeout
language: python
rule:
  pattern: requests.get($$$)
  not:
    has:
      pattern: timeout = $_
' .

# Find asyncio.sleep() outside while loops
ast-grep --inline-rules '
id: find-sleep-not-in-loop
language: python
rule:
  pattern: asyncio.sleep($$$)
  not:
    inside:
      kind: while_statement
' .
```

### Output Modes

Control what ast-grep shows:

```bash
# Show matching lines (default)
ast-grep -p 'pattern' -l python src/

# Show JSON output for scripting
ast-grep -p 'pattern' -l python src/ --json

# Show debug info (AST structure)
ast-grep -p 'pattern' -l python src/ --debug-query=ast
```

## Transforming Code

### Simple Transformations

Use `-p` and `-r` for direct pattern replacement:

```bash
# Rename function calls
ast-grep -U -p 'old_api($$$ARGS)' -r 'new_api($$$ARGS)' .

# Change method call style
ast-grep -U -p 'module.function($OBJ, $$$ARGS)' -r '$OBJ.function($$$ARGS)' .
```

### Complex Transformations

Use `--inline-rules` for transformations requiring conditions:

```bash
# Add timeout to requests.get() calls that lack it
ast-grep -U --inline-rules '
id: add-timeout
language: python
rule:
  pattern: requests.get($$$ARGS)
  not:
    has:
      pattern: timeout = $_
  fix: requests.get($$$ARGS, timeout=10)
' .

# Remove keyword argument from any position
ast-grep -U --inline-rules '
id: remove-cache-kwarg
language: python
rule:
  any:
    - pattern: my_function($$$START, cache=$_, $$$END)
      fix: my_function($$$START, $$$END)
    - pattern: my_function(cache=$_, $$$END)
      fix: my_function($$$END)
    - pattern: my_function(cache=$_)
      fix: my_function()
' .
```

**See `references/transformations.md` for more transformation recipes.**

### When to Use Each Approach

**Use `-p` and `-r`** when:
- Simple, unconditional replacement
- Direct pattern mapping
- No special logic needed

**Use `--inline-rules`** when:
- Multiple patterns to match (`any`, `all`)
- Conditional transformations (`not`, `has`, `inside`)
- Order-independent argument matching
- Multiple related transformations in one pass

## Creating Rules

ast-grep can enforce code quality through YAML rule files. Rules come in two types:

### Conformance Rules (severity: error)

Block commits and enforce code standards:

```yaml
# .ast-grep/rules/no-eval.yml
id: no-eval
language: python
severity: error
message: "Avoid eval() - it's a security risk"
note: |
  eval() executes arbitrary code and is a security vulnerability.

  Instead:
  - Use ast.literal_eval() for safe literal evaluation
  - Use domain-specific parsers for structured input

  For exemptions:
    # ast-grep-ignore: no-eval - REPL implementation needs eval
    result = eval(code)
rule:
  pattern: eval($$$)
```

**Test the rule:**

```bash
# Scan specific files
ast-grep scan --rule .ast-grep/rules/no-eval.yml src/

# Scan all files
ast-grep scan --rule .ast-grep/rules/no-eval.yml
```

### Hint Rules (severity: hint)

Provide suggestions without blocking:

```yaml
# .ast-grep/rules/hints/prefer-pathlib.yml
id: prefer-pathlib
language: python
severity: hint
message: "Consider using pathlib.Path instead of os.path"
note: |
  pathlib provides a more modern, object-oriented interface.

  This is a suggestion, not a requirement. os.path is still valid.
rule:
  any:
    - pattern: os.path.$METHOD($$$)
    - pattern: os.path.join($$$)
```

### Rule Structure

All rules follow this structure:

```yaml
id: rule-identifier          # Unique ID (kebab-case)
language: python             # Target language
severity: error              # 'error' or 'hint'
message: "Short description" # One-line summary
note: |                      # Multi-line explanation
  Detailed explanation
  Examples of bad vs good
  Exemption instructions
rule:                        # Matching pattern
  pattern: banned($$$)
  # OR complex rule:
  # all:
  #   - pattern: func($$$)
  #   - not:
  #       has:
  #         pattern: required = $_
```

**See `references/rules.md` for complete rule creation guide.**

## Debugging Patterns

### View AST Structure

Understand how ast-grep sees your code:

```bash
# Show AST for a pattern
ast-grep -p 'async def $FUNC($$$): $$$' --debug-query=ast

# Show AST for specific code
echo 'async def foo(): pass' | ast-grep -p '$$$' --debug-query=ast
```

### Testing Patterns

Test patterns incrementally to ensure they match what you expect:

```bash
# Test pattern without modification
ast-grep -p 'your_pattern' -l python .

# Test on a small subset first
ast-grep -p 'your_pattern' -l python src/specific_file.py

# Use --json for programmatic validation
ast-grep -p 'your_pattern' -l python . --json
```

### Common Pattern Pitfalls

**Invalid syntax:**
```yaml
# ❌ Not valid Python
pattern: async def

# ✅ Valid - complete statement
pattern: 'async def $FUNC($$$): $$$'
```

**Lowercase metavariables:**
```yaml
# ❌ Invalid
pattern: $myvar = $value

# ✅ Valid
pattern: $MY_VAR = $VALUE
```

**Text-based matching:**
```yaml
# ❌ Won't match comments
pattern: TODO

# ✅ Use grep for text
```

**See `references/pattern-syntax.md` for comprehensive pattern syntax guide.**

## Common Workflows

### Workflow 1: Renaming a Function Across Codebase

1. **Test the pattern** to see all matches:
   ```bash
   ast-grep -p 'old_function($$$ARGS)' -l python .
   ```

2. **Review matches** to ensure they're correct

3. **Apply transformation** with `-U` flag:
   ```bash
   ast-grep -U -p 'old_function($$$ARGS)' -r 'new_function($$$ARGS)' .
   ```

4. **Run tests** to verify the changes work

### Workflow 2: Creating a Code Quality Rule

1. **Identify the anti-pattern** to ban

2. **Write a simple pattern** to match it:
   ```bash
   ast-grep -p 'dangerous_function($$$)' -l python src/
   ```

3. **Create rule file** (`.ast-grep/rules/no-dangerous-function.yml`):
   ```yaml
   id: no-dangerous-function
   language: python
   severity: error
   message: "Avoid dangerous_function() - use safe_function() instead"
   note: |
     Explanation and examples here
   rule:
     pattern: dangerous_function($$$)
   ```

4. **Test the rule**:
   ```bash
   ast-grep scan --rule .ast-grep/rules/no-dangerous-function.yml
   ```

5. **Handle existing violations** with exemptions if needed

### Workflow 3: Complex Code Transformation

1. **Identify all pattern variations** that need transformation

2. **Create inline rules** with `any` to handle all cases:
   ```bash
   ast-grep --inline-rules '
   id: my-transformation
   language: python
   rule:
     any:
       - pattern: variant1($$$)
         fix: new_api($$$)
       - pattern: variant2($$$)
         fix: new_api($$$)
   ' .
   ```

3. **Test without `-U`** to preview changes

4. **Apply with `-U`** when confident

5. **Run linters and tests** to verify

## Resources

### Bundled References

This skill includes detailed reference documentation:

- **`references/pattern-syntax.md`** - Complete pattern syntax reference including metavariables, relational operators (all, any, not, has, inside), and common patterns by language
- **`references/transformations.md`** - Transformation recipes for common refactoring tasks with examples of when to use simple vs complex approaches
- **`references/rules.md`** - Complete guide to creating conformance and hint rules, including testing, exemptions, and best practices

Load these references when working on complex patterns, transformations, or rule creation.

### External Resources

- [Official Documentation](https://ast-grep.github.io/)
- [Pattern Syntax Guide](https://ast-grep.github.io/guide/pattern-syntax.html)
- [Rule Configuration Reference](https://ast-grep.github.io/guide/rule-config.html)
- [Python Pattern Catalog](https://ast-grep.github.io/catalog/python/)

### Quick Command Reference

```bash
# Search
ast-grep -p 'pattern' -l python src/

# Transform (preview first!)
ast-grep -p 'old' -r 'new' .        # Preview
ast-grep -U -p 'old' -r 'new' .     # Apply

# Complex rules
ast-grep --inline-rules 'YAML' .

# Scan with rule file
ast-grep scan --rule my-rule.yml

# Debug AST
ast-grep -p 'pattern' --debug-query=ast
```

