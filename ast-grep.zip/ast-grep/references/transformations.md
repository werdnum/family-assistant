# ast-grep Transformation Recipes

This document provides recipe-style examples for using ast-grep to make mechanical code transformations.

## When to Use Simple vs Complex Transformations

### Use Simple `-p` and `-r` Flags

When transformation is straightforward and unconditional:

```bash
ast-grep -U -p 'old_function($$$ARGS)' -r 'new_function($$$ARGS)' .
```

**Characteristics:**
- Direct pattern-to-replacement mapping
- No conditional logic needed
- Single pattern matches all cases
- Pattern and replacement are symmetric

### Use `--inline-rules` with Complex Rules

When transformation requires:
- Multiple pattern variations (`any`, `all`)
- Conditional logic (`not`, `has`, `inside`)
- Order-independent argument matching
- Different fixes for different patterns

```bash
ast-grep -U --inline-rules '
id: my-transformation
language: python
rule:
  pattern: my_function($$$)
  not:
    has:
      pattern: required_arg = $_
  fix: my_function($$$, required_arg=default)
' .
```

## Recipe 1: Simple Function Rename

**Task:** Rename a function across the entire codebase.

**Before:**
```python
result = old_function(arg1, arg2, kwarg=value)
data = old_function(x)
```

**Command:**
```bash
ast-grep -U -p 'old_function($$$ARGS)' -r 'new_function($$$ARGS)' .
```

**After:**
```python
result = new_function(arg1, arg2, kwarg=value)
data = new_function(x)
```

## Recipe 2: Changing Module Method to Instance Method

**Task:** Convert `module.method(object, args)` to `object.method(args)`.

**Before:**
```python
my_instance = MyClass()
mymodule.mymethod(my_instance, 'arg1', kwarg='value')
mymodule.mymethod(obj, x, y, z)
```

**Command:**
```bash
ast-grep -U -p 'mymodule.mymethod($OBJECT, $$$ARGS)' -r '$OBJECT.mymethod($$$ARGS)' .
```

**After:**
```python
my_instance = MyClass()
my_instance.mymethod('arg1', kwarg='value')
obj.mymethod(x, y, z)
```

## Recipe 3: Removing a Keyword Argument

**Task:** Remove `cache=...` keyword argument from all positions.

**Challenge:** The argument can appear at the beginning, middle, or end of the argument list, and comma handling varies by position.

**Before:**
```python
my_function(arg1, cache=True, other_arg=123)
my_function(cache=True, other_arg=123)
my_function(arg1, cache=True)
my_function(cache=True)
```

**Command:**
```bash
ast-grep -U --inline-rules '
id: remove-cache-kwarg
language: python
rule:
  any:
    - pattern: my_function($$$START, cache=$_, $$$END)
      fix: my_function($$$START, $$$END)
    - pattern: my_function(cache=$_, $$$END)
      fix: my_function($$$END)
    - pattern: my_function(cache=$_)
      fix: my_function()
' .
```

**After:**
```python
my_function(arg1, other_arg=123)
my_function(other_arg=123)
my_function(arg1)
my_function()
```

**Why this approach:**
- First pattern handles cache in middle: `func(start, cache=X, end)`
- Second pattern handles cache at beginning: `func(cache=X, end)`
- Third pattern handles cache as only arg: `func(cache=X)`
- Order matters: most specific patterns first

## Recipe 4: Adding a Keyword Argument Conditionally

**Task:** Add `timeout=10` to `requests.get()` calls, but only if they don't already have a timeout.

**Before:**
```python
requests.get("https://api.example.com/status")
requests.get("https://api.example.com/data", timeout=5)
requests.get(url, headers=headers)
```

**Command:**
```bash
ast-grep -U --inline-rules '
id: add-timeout
language: python
rule:
  pattern: requests.get($$$ARGS)
  not:
    has:
      pattern: timeout = $_
  fix: requests.get($$$ARGS, timeout=10)
' .
```

**After:**
```python
requests.get("https://api.example.com/status", timeout=10)
requests.get("https://api.example.com/data", timeout=5)
requests.get(url, headers=headers, timeout=10)
```

**Key concepts:**
- `has` checks if pattern exists anywhere in the arguments
- `not` negates the check
- Only modifies calls that lack the timeout argument

## Recipe 5: Unifying Multiple Function Names

**Task:** Consolidate `send_json_payload()` and `post_data_as_json()` to `api_client.post()` with order-independent argument matching.

**Before:**
```python
send_json_payload(endpoint="/users", data={"name": "Alice"})
post_data_as_json(json_body={"name": "Bob"}, url="/products")
send_json_payload(data=payload, endpoint=endpoint)
```

**Command:**
```bash
ast-grep -U --inline-rules '
id: unify-json-functions
language: python
rule:
  any:
    - all:
        - pattern: send_json_payload($$$_)
        - has: {pattern: endpoint = $URL}
        - has: {pattern: data = $PAYLOAD}
    - all:
        - pattern: post_data_as_json($$$_)
        - has: {pattern: url = $URL}
        - has: {pattern: json_body = $PAYLOAD}
  fix: api_client.post(url=$URL, json=$PAYLOAD)
' .
```

**After:**
```python
api_client.post(url="/users", json={"name": "Alice"})
api_client.post(url="/products", json={"name": "Bob"})
api_client.post(url=endpoint, json=payload)
```

**Key concepts:**
- `any` matches either function
- `all` ensures both required arguments are present
- `has` matches arguments regardless of order
- Different argument names map to unified interface

## Recipe 6: Modernizing unittest Assertions to pytest

**Task:** Convert unittest-style assertions to pytest assert statements.

**Before:**
```python
self.assertEqual(result, 4)
self.assertTrue(is_active)
self.assertIsNone(value)
self.assertFalse(condition)
```

**Command:**
```bash
ast-grep -U --inline-rules '
- id: refactor-assertEqual
  language: python
  rule: {pattern: self.assertEqual($A, $B), fix: "assert $A == $B"}
- id: refactor-assertTrue
  language: python
  rule: {pattern: self.assertTrue($A), fix: "assert $A"}
- id: refactor-assertFalse
  language: python
  rule: {pattern: self.assertFalse($A), fix: "assert not $A"}
- id: refactor-assertIsNone
  language: python
  rule: {pattern: self.assertIsNone($A), fix: "assert $A is None"}
' .
```

**After:**
```python
assert result == 4
assert is_active
assert value is None
assert not condition
```

**Why multiple rules:**
- Each assertion type needs different transformation
- Bundling related transformations in one command
- Each rule has its own ID for clarity

## Recipe 7: Changing Import Patterns

**Task:** Change from `from module import *` to specific imports.

**Before:**
```python
from mymodule import *

result = function_a()
data = function_b(x)
```

**Approach:**
This requires two steps:
1. Find what's being used from the module
2. Replace the wildcard import

**Step 1 - Find usages:**
```bash
# This is typically a manual analysis step or requires custom scripting
ast-grep -p '$FUNC($$$)' -l python file.py --json
```

**Step 2 - Replace import:**
```bash
ast-grep -U -p 'from mymodule import *' -r 'from mymodule import function_a, function_b' .
```

## Recipe 8: Adding Decorators

**Task:** Add `@property` decorator to getter methods.

**Before:**
```python
def get_name(self):
    return self._name

def get_value(self):
    return self._value
```

**Command:**
```bash
ast-grep -U --inline-rules '
id: add-property-decorator
language: python
rule:
  pattern: |
    def get_$NAME(self):
        return $$$
  fix: |
    @property
    def get_$NAME(self):
        return $$$
' .
```

**After:**
```python
@property
def get_name(self):
    return self._name

@property
def get_value(self):
    return self._value
```

## Recipe 9: Context-Aware Transformations

**Task:** Replace `time.sleep()` with `asyncio.sleep()` but only in async functions.

**Before:**
```python
async def async_function():
    time.sleep(1)

def sync_function():
    time.sleep(1)
```

**Command:**
```bash
ast-grep -U --inline-rules '
id: time-to-asyncio-sleep
language: python
rule:
  pattern: time.sleep($DURATION)
  inside:
    pattern:
      context: "async def $$$: $$$"
      selector: function_definition
  fix: await asyncio.sleep($DURATION)
' .
```

**After:**
```python
async def async_function():
    await asyncio.sleep(1)

def sync_function():
    time.sleep(1)  # Unchanged - not in async context
```

**Key concepts:**
- `inside` ensures transformation only applies in specific context
- `context` and `selector` handle patterns with unnamed nodes (async keyword)
- Sync functions remain unchanged

## Best Practices

### 1. Always Test First

Preview changes before applying:
```bash
# Test without -U
ast-grep -p 'pattern' -r 'replacement' .

# Review all matches
# Then apply with -U
ast-grep -U -p 'pattern' -r 'replacement' .
```

### 2. Start Simple, Build Complex

Begin with basic pattern, add constraints incrementally:
```bash
# Step 1: Basic pattern
ast-grep -p 'my_function($$$)' -l python .

# Step 2: Add conditions if needed
ast-grep --inline-rules '
rule:
  pattern: my_function($$$)
  not:
    has:
      pattern: required = $_
' .
```

### 3. Handle Edge Cases

Consider all argument positions for keyword arguments:
- At the beginning
- In the middle
- At the end
- As the only argument

### 4. Use Version Control

Make transformations on a clean branch:
```bash
git checkout -b refactor-function-names
ast-grep -U -p 'old($$$)' -r 'new($$$)' .
git diff  # Review changes
git add -p  # Stage changes selectively
```

### 5. Verify After Transformation

Run tests and linters:
```bash
# After transformation
ast-grep -U -p 'pattern' -r 'replacement' .

# Run linters
ruff check .
pylint src/

# Run tests
pytest
```

## Common Patterns by Language

### Python

```bash
# Function definitions
ast-grep -p 'def $FUNC($$$): $$$' -l python

# Method calls
ast-grep -p '$OBJ.$METHOD($$$)' -l python

# Imports
ast-grep -p 'from $MODULE import $NAME' -l python

# Class definitions
ast-grep -p 'class $CLASS($$$): $$$' -l python

# List comprehensions
ast-grep -p '[$EXPR for $VAR in $ITER]' -l python
```

### JavaScript/TypeScript

```bash
# Arrow functions
ast-grep -p '($$$PARAMS) => $$$BODY' -l javascript

# Function declarations
ast-grep -p 'function $NAME($$$) { $$$ }' -l javascript

# React hooks
ast-grep -p 'use$HOOK($$$)' -l javascript

# Object destructuring
ast-grep -p 'const { $$$PROPS } = $OBJ' -l javascript
```

## Troubleshooting

### Pattern Doesn't Match

**Issue:** Pattern seems correct but doesn't match code.

**Solution:**
```bash
# Check AST structure
ast-grep -p 'your_pattern' --debug-query=ast

# Verify pattern is valid syntax
echo 'def example(): pass' | ast-grep -p 'def $FUNC($$$): $$$'
```

### Too Many Matches

**Issue:** Pattern matches more than intended.

**Solution:** Add constraints with `inside`, `not`, `has`:
```bash
ast-grep --inline-rules '
rule:
  pattern: broad_pattern($$$)
  inside:
    pattern: def specific_context($$$): $$$
' .
```

### Comma Issues

**Issue:** Removing an argument leaves extra commas.

**Solution:** Use multiple patterns to handle all positions:
```bash
ast-grep --inline-rules '
rule:
  any:
    - pattern: func($$$START, arg=$_, $$$END)
      fix: func($$$START, $$$END)
    - pattern: func(arg=$_, $$$END)
      fix: func($$$END)
    - pattern: func(arg=$_)
      fix: func()
' .
```

