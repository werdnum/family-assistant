# ast-grep Rule Creation Guide

This document provides comprehensive guidance for creating ast-grep rules for code quality enforcement.

## Overview

ast-grep rules define code patterns to enforce (conformance rules) or suggest (hint rules). Rules are YAML files that specify:
- What pattern to match
- Why it's problematic or suboptimal
- How to fix it
- When to allow exemptions

## Rule Types

### Conformance Rules (`severity: error`)

**Purpose:** Enforce code quality by banning anti-patterns

**Characteristics:**
- Located in `.ast-grep/rules/`
- `severity: error`
- Block commits when violated
- Can be exempted with inline comments or exemptions file
- Used to prevent bugs and maintainability issues

**When to create:**
- Pattern reliably indicates a problem
- Alternative approach exists
- Team agrees the pattern should be banned
- Cost of false positives is low

**Examples:**
- `no-asyncio-sleep-in-tests` - Prevents flaky tests
- `no-eval` - Prevents security vulnerabilities
- `require-timeout-on-requests` - Prevents hanging requests

### Hint Rules (`severity: hint`)

**Purpose:** Provide helpful suggestions and best practices

**Characteristics:**
- Located in `.ast-grep/rules/hints/`
- `severity: hint`
- Never block commits or fail builds
- Purely informational
- Used for education and awareness

**When to create:**
- Pattern suggests a potential improvement
- There are legitimate exceptions
- Want to raise awareness without enforcing
- Modernization or style suggestions

**Examples:**
- `prefer-pathlib` - Suggests modern path handling
- `consider-async-mock` - Suggests AsyncMock in async contexts
- `prefer-pytest-fixtures` - Suggests pytest over unittest fixtures

## Rule File Structure

All rules follow this structure:

```yaml
id: rule-identifier               # Unique ID (kebab-case)
language: python                  # Target language
severity: error                   # 'error' or 'hint'
message: "Short description"      # One-line summary shown to user
note: |                          # Detailed explanation (multi-line)
  Longer explanation of why this pattern is problematic.

  Show examples of the problem and the solution.

  Explain any exemptions or edge cases.
rule:                            # The actual matching rule
  pattern: banned_function($$$)  # Simple pattern
  # OR complex rule with operators:
  all:
    - pattern: some_function($$$)
    - not:
        has:
          pattern: required_arg = $_
```

### Field Descriptions

**`id`** (required)
- Unique identifier for the rule
- Use kebab-case (lowercase with hyphens)
- Conformance: `no-banned-pattern` or `require-good-pattern`
- Hints: `prefer-better-pattern` or `consider-alternative`
- Examples: `no-eval`, `prefer-pathlib`, `require-timeout`

**`language`** (required)
- Target programming language
- Common values: `python`, `javascript`, `typescript`, `rust`, `go`, `java`
- Must match exactly (case-sensitive)

**`severity`** (required)
- `error` - Conformance rule (blocks commits)
- `hint` - Suggestion (never blocks)
- `warning` - Medium priority (rarely used)

**`message`** (required)
- One-line summary shown in output
- Should be clear and actionable
- Start with verb: "Avoid X", "Use Y instead of Z", "Consider X"
- Keep under 80 characters if possible

**`note`** (optional but recommended)
- Detailed, multi-line explanation
- Include why the pattern is problematic
- Show before/after examples
- Explain exemption process
- Use markdown for formatting

**`rule`** (required)
- The pattern matching logic
- Can be simple pattern or complex rule with operators
- See pattern syntax reference for details

### Optional Fields

**`fix`** - Auto-fix suggestion:
```yaml
rule:
  pattern: old_api($$$ARGS)
  fix: new_api($$$ARGS)
```

**`metadata`** - Additional information:
```yaml
metadata:
  category: security
  tags: [sql-injection, user-input]
  documentation: https://docs.example.com/security
```

## Creating a Conformance Rule: Step-by-Step

### Step 1: Identify the Anti-Pattern

What code pattern do you want to ban? Examples:
- Function that's prone to errors
- API that's been deprecated
- Pattern that causes performance issues
- Security vulnerability

**Example:** Ban `eval()` in production code because it's a security risk.

### Step 2: Choose a Rule ID

Follow naming conventions:
- Use kebab-case
- Start with `no-` for banned patterns
- Start with `require-` for required patterns
- Be specific and descriptive

**Example:** `no-eval-in-production`

### Step 3: Write the Pattern

Start with a simple pattern:

```yaml
pattern: eval($$$)
```

Test it:
```bash
ast-grep -p 'eval($$$)' -l python src/
```

Review matches to ensure pattern is correct.

### Step 4: Add Constraints (if needed)

Refine the pattern to avoid false positives:

```yaml
# Only match eval outside test functions
rule:
  pattern: eval($$$)
  not:
    inside:
      pattern: def test_$$$(): $$$
```

Or use file-based filtering (configure in checker script).

### Step 5: Write the Complete Rule

Create `.ast-grep/rules/no-eval-in-production.yml`:

```yaml
id: no-eval-in-production
language: python
severity: error
message: "Avoid eval() - it's a security risk"
note: |
  eval() executes arbitrary Python code and is a security vulnerability.

  Instead, use safer alternatives:

  # ❌ Bad - security risk
  result = eval(user_input)

  # ✅ Good - use ast.literal_eval for safe evaluation
  import ast
  result = ast.literal_eval(user_input)

  # ✅ Good - use a parser for specific use cases
  result = parse_expression(user_input)

  For exemptions (e.g., REPL implementation):
    # ast-grep-ignore: no-eval-in-production - REPL needs eval for evaluation
    result = eval(code)
rule:
  pattern: eval($$$)
```

### Step 6: Test the Rule

Test on actual code:

```bash
# Test on specific files
ast-grep scan --rule .ast-grep/rules/no-eval-in-production.yml src/

# Test on all files
ast-grep scan --rule .ast-grep/rules/no-eval-in-production.yml
```

Verify:
- Matches all intended violations
- No false positives
- Clear, actionable error messages

### Step 7: Handle Existing Violations

If there are existing violations that can't be fixed immediately:

**Option 1: Inline exemptions**
```python
# ast-grep-ignore: no-eval-in-production - REPL implementation requires eval
result = eval(code)
```

**Option 2: File-level exemptions** (`.ast-grep/exemptions.yml`):
```yaml
exemptions:
  - rule: no-eval-in-production
    files:
      - src/repl/evaluator.py
      - src/debug/*.py
    reason: "REPL implementation requires eval for code evaluation"
    ticket: "#123"  # Optional: tracking issue for removal
```

### Step 8: Document the Rule

Update rule documentation (e.g., `.ast-grep/rules/README.md`):

```markdown
#### `no-eval-in-production`

**Pattern**: `eval($$$)` in production code

**Why it's banned**: eval() is a security vulnerability that executes arbitrary code.

**Replacement**:
- Use `ast.literal_eval()` for safe evaluation of literals
- Use domain-specific parsers for structured input
- Use `compile()` with restricted globals for safe code execution

**Exemptions**: Add inline comment with justification
```

### Step 9: Integrate with CI/CD (if applicable)

Ensure rule runs in:
- Pre-commit hooks
- CI/CD pipeline
- Lint scripts

## Creating a Hint Rule: Step-by-Step

Hint rules follow the same process with these differences:

1. **Save to hints directory:** `.ast-grep/rules/hints/rule-name.yml`

2. **Use `severity: hint`:**
```yaml
severity: hint
```

3. **More permissive messaging:**
```yaml
message: "Consider using pathlib.Path instead of os.path"
note: |
  pathlib provides a more modern, object-oriented interface.

  This is a suggestion, not a requirement. os.path is still valid.
```

4. **No need for extensive documentation:** Hints are opt-in information, less formal than conformance rules

**Example hint rule:**

```yaml
# .ast-grep/rules/hints/prefer-pathlib.yml
id: prefer-pathlib
language: python
severity: hint
message: "Consider using pathlib.Path instead of os.path"
note: |
  pathlib provides a more modern, object-oriented interface for file paths.

  # ⚠️ Old style
  path = os.path.join(dir, filename)
  if os.path.exists(path):
      with open(path) as f:
          data = f.read()

  # ✅ Modern style
  path = Path(dir) / filename
  if path.exists():
      data = path.read_text()

  This is a suggestion, not a requirement. os.path is still valid.
rule:
  any:
    - pattern: os.path.$METHOD($$$)
    - pattern: os.path.join($$$)
```

## Advanced Rule Patterns

### Pattern with Auto-Fix

```yaml
id: use-new-api
language: python
severity: error
message: "Use new_api() instead of deprecated old_api()"
rule:
  pattern: old_api($$$ARGS)
  fix: new_api($$$ARGS)
```

### Context-Aware Rules

```yaml
id: no-time-sleep-in-async
language: python
severity: error
message: "Use asyncio.sleep() in async functions, not time.sleep()"
rule:
  pattern: time.sleep($$$)
  inside:
    pattern:
      context: 'async def $$$: $$$'
      selector: function_definition
  fix: await asyncio.sleep($$$)
```

### Multiple Pattern Variations

```yaml
id: ban-multiple-sleep-functions
language: python
severity: error
message: "Avoid sleep functions in tests"
rule:
  any:
    - pattern: time.sleep($$$)
    - pattern: asyncio.sleep($$$)
    - pattern: trio.sleep($$$)
```

### Conditional Patterns

```yaml
id: require-timeout-on-requests
language: python
severity: error
message: "Always specify timeout for requests.get()"
rule:
  all:
    - pattern: requests.get($$$)
    - not:
        has:
          pattern: timeout = $_
  fix: requests.get($$$, timeout=30)
```

### Excluding Specific Contexts

```yaml
id: no-print-in-production
language: python
severity: error
message: "Use logging instead of print() in production code"
rule:
  pattern: print($$$)
  not:
    any:
      - inside:
          pattern: def test_$$$(): $$$
      - inside:
          pattern: if __name__ == "__main__": $$$
```

## Testing Rules

### Manual Testing

```bash
# Test rule on specific files
ast-grep scan --rule my-rule.yml src/file.py

# Test on directory
ast-grep scan --rule my-rule.yml src/

# Test all files
ast-grep scan --rule my-rule.yml

# JSON output for scripting
ast-grep scan --rule my-rule.yml --json
```

### Test Cases to Consider

1. **Positive matches** - Code that should be flagged
2. **Negative matches** - Similar code that shouldn't be flagged
3. **Edge cases:**
   - Different argument positions
   - Zero arguments
   - Many arguments
   - Multi-line formatting
   - With comments
   - Nested in different contexts

### Example Test Process

```bash
# Create test file with violations
cat > test_violations.py << 'EOF'
# Should match
eval("1 + 1")
result = eval(user_input)

# Should not match (in test)
def test_eval():
    eval("test")
EOF

# Test the rule
ast-grep scan --rule .ast-grep/rules/no-eval-in-production.yml test_violations.py

# Verify correct matches
# Clean up
rm test_violations.py
```

## Exemptions

### Types of Exemptions

**1. Inline exemptions** - For single lines:
```python
# ast-grep-ignore: rule-id - Reason why exemption is needed
problematic_code()
```

**2. Block exemptions** - For multiple lines:
```python
# ast-grep-ignore-block: rule-id - Reason
def function_with_multiple_violations():
    problematic_code_1()
    problematic_code_2()
# ast-grep-ignore-end
```

**3. File-level exemptions** - In `.ast-grep/exemptions.yml`:
```yaml
exemptions:
  - rule: rule-id
    files:
      - path/to/file.py
      - path/to/dir/*.py
    reason: "Explanation of why exemption is needed"
    ticket: "#123"  # Optional tracking issue
```

### Exemption Guidelines

**Use exemptions when:**
- The spirit of the rule doesn't apply to this specific case
- There's no practical alternative
- Code legitimately needs the banned pattern
- Temporary exemption with plan to fix (ticket)

**DON'T use exemptions to:**
- Avoid fixing code that should be fixed
- Bypass code review
- Hide technical debt without a plan

### Exemption Best Practices

1. **Be specific:** Explain exactly why the exemption is needed
2. **Add context:** Reference tickets, requirements, or constraints
3. **Prefer narrow scope:** Inline > block > file-level
4. **Review regularly:** Audit exemptions periodically
5. **Track removal:** Include ticket numbers for future cleanup

**Good exemption:**
```python
# ast-grep-ignore: no-asyncio-sleep-in-tests - wait_for_condition() implementation itself needs sleep for polling
await asyncio.sleep(poll_interval)
```

**Bad exemption:**
```python
# ast-grep-ignore: no-asyncio-sleep-in-tests
await asyncio.sleep(2)  # No reason provided!
```

## Rule Naming Conventions

### Conformance Rules

**Ban patterns:**
- `no-{pattern}` - General bans
- `no-{pattern}-in-{context}` - Context-specific bans
- Examples: `no-eval`, `no-asyncio-sleep-in-tests`, `no-mutable-defaults`

**Require patterns:**
- `require-{pattern}` - Required patterns
- Examples: `require-timeout`, `require-type-hints`, `require-docstring`

### Hint Rules

**Suggestions:**
- `prefer-{pattern}` - Style preferences
- `consider-{pattern}` - Soft suggestions
- `use-{pattern}-for-{purpose}` - Specific recommendations
- Examples: `prefer-pathlib`, `consider-async-mock`, `use-comprehension-for-map`

## Common Pitfalls

### Pitfall 1: Pattern Too Broad

```yaml
# ❌ Matches ALL function calls
pattern: $FUNC($$$)

# ✅ Be specific or add constraints
pattern: dangerous_function($$$)

# OR
rule:
  pattern: $FUNC($$$)
  inside:
    kind: specific_context
```

### Pitfall 2: Missing Edge Cases

Test against:
- Different argument orders
- Zero arguments
- Multi-line formatting
- Nested contexts

### Pitfall 3: Unclear Error Messages

```yaml
# ❌ Vague message
message: "Don't do this"

# ✅ Clear and actionable
message: "Avoid eval() - use ast.literal_eval() instead"
```

### Pitfall 4: Not Providing Alternatives

Always explain what to do instead:

```yaml
note: |
  ❌ Bad: sleep() is flaky

  ✅ Good: Use wait_for_condition() instead:
    await wait_for_condition(lambda: check(), timeout=5.0)
```

### Pitfall 5: Inconsistent Rule IDs

Follow the naming convention consistently:
- `no-banned-pattern`
- `require-needed-pattern`
- `prefer-better-pattern`

## Best Practices

### 1. Start Simple, Add Complexity

```yaml
# Start with basic pattern
pattern: dangerous_function($$$)

# Add constraints as needed
rule:
  pattern: dangerous_function($$$)
  not:
    has:
      pattern: safe_mode = True
```

### 2. Provide Clear Examples

```yaml
note: |
  # ❌ Bad
  old_api(data)

  # ✅ Good
  new_api(payload=data, timeout=30)
```

### 3. Explain the Why

```yaml
note: |
  eval() executes arbitrary code and is a security vulnerability.
  Attackers can inject malicious code through user input.
```

### 4. Make Exemptions Easy

```yaml
note: |
  For legitimate use cases (e.g., REPL):
    # ast-grep-ignore: rule-id - REPL needs eval
    result = eval(code)
```

### 5. Test Thoroughly

Test on real codebase before deploying:
```bash
ast-grep scan --rule my-rule.yml .
```

Review all matches for false positives.

## Rule Checklist

Before committing a new rule:

- [ ] Rule ID follows naming convention
- [ ] Pattern matches intended violations
- [ ] Pattern doesn't have false positives
- [ ] Message is clear and actionable
- [ ] Note explains why and provides alternatives
- [ ] Note explains exemption process
- [ ] Tested on real code
- [ ] Existing violations handled (fixed or exempted)
- [ ] Documentation updated (if conformance rule)
- [ ] Integrated with CI/CD (if applicable)

## Quick Reference

```yaml
# Basic rule template
id: rule-name
language: python
severity: error  # or 'hint'
message: "Short actionable message"
note: |
  Why this is problematic.

  # ❌ Bad example
  bad_code()

  # ✅ Good alternative
  good_code()

  Exemptions: # ast-grep-ignore: rule-name - reason
rule:
  pattern: banned_pattern($$$)
```

```bash
# Test rule
ast-grep scan --rule my-rule.yml path/

# Apply auto-fix (if rule has 'fix')
ast-grep -U --rule my-rule.yml path/
```

