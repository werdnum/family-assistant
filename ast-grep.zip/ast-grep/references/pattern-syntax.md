# ast-grep Pattern Syntax Reference

This document provides comprehensive pattern syntax reference for ast-grep.

## Core Principle

**ast-grep patterns must be valid, parseable code** in the target language. They match AST nodes, not text strings.

```python
# ✅ Valid pattern - this is valid Python syntax
pattern: asyncio.sleep($$$)

# ❌ Invalid pattern - not valid Python syntax
pattern: asyncio.sleep(  # Missing closing paren
```

ast-grep understands code structure through the Abstract Syntax Tree (AST), which means:
- Whitespace and formatting don't affect matching (by default)
- Comments are ignored
- Code structure matters, not text appearance
- Patterns must follow language grammar rules

## Metavariables

Metavariables are placeholders that match code elements. They're the key to writing flexible patterns.

### Single Node: `$VAR`

Matches a single AST node.

**Naming rules:**
- Must start with `$`
- Followed by uppercase letters, underscores, or digits only
- Valid: `$VAR`, `$META_VAR1`, `$123`, `$_VAR`
- Invalid: `$invalid`, `$myVar`, `$Svalue` (lowercase letters)

**Examples:**
```python
# Match variable assignment
pattern: $VAR = $VALUE
# Matches: x = 42, name = "Alice", result = get_data()

# Match function call with single argument
pattern: print($MSG)
# Matches: print("hello"), print(result), print(x)

# Match attribute access
pattern: $OBJ.$ATTR
# Matches: user.name, data.value, self.id
```

### Multiple Nodes: `$$$NAME`

Matches zero or more AST nodes (ellipsis metavariable).

**Examples:**
```python
# Match function call with any arguments
pattern: my_function($$$ARGS)
# Matches: my_function(), my_function(1), my_function(1, 2, x=3)

# Match function with any parameters
pattern: def $FUNC($$$PARAMS): $$$BODY
# Matches: def foo():, def bar(x):, def baz(x, y, z=1):

# Match method call with any arguments
pattern: $OBJ.$METHOD($$$ARGS)
# Matches: user.save(), data.load(file), obj.method(1, 2, key=val)
```

**Multiple ellipsis in one pattern:**
```python
# Match function call with something before and after target arg
pattern: my_function($$$START, target=$VALUE, $$$END)
# Matches: my_function(target=5)
# Matches: my_function(a, target=5, b, c)
# Matches: my_function(target=5, x=1)
```

### Anonymous Match: `$_`

Matches a single node but doesn't capture it. Use when you don't need to reference the matched value.

**Examples:**
```python
# Match any function call with exactly one argument (don't care what it is)
pattern: process($_)
# Matches: process(data), process(42), process("text")

# Match assignments where we only care about the variable, not the value
pattern: $VAR = $_
# Matches: x = 42, name = "Alice", result = compute()

# Check for presence of argument without caring about its value
pattern: requests.get($$$, timeout=$_)
# Matches any requests.get() with a timeout, regardless of timeout value
```

## Relational Operators

Combine patterns to create complex matching logic.

### `all` - Match When ALL Conditions Are True

All conditions must be satisfied for the pattern to match.

```yaml
rule:
  all:
    - pattern: requests.get($$$ARGS)
    - not:
        has:
          pattern: timeout = $_
```

Matches `requests.get()` calls that DON'T have a timeout argument.

**Another example:**
```yaml
rule:
  all:
    - pattern: my_function($$$)
    - has: {pattern: required_arg = $_}
    - has: {pattern: another_arg = $_}
```

Matches `my_function()` that has BOTH required_arg and another_arg.

### `any` - Match When ANY Condition Is True

At least one condition must be satisfied.

```yaml
rule:
  any:
    - pattern: time.sleep($$$)
    - pattern: asyncio.sleep($$$)
    - pattern: trio.sleep($$$)
```

Matches any of the three sleep functions.

**Use for variations:**
```yaml
rule:
  any:
    - pattern: old_api_v1($$$)
    - pattern: old_api_v2($$$)
    - pattern: legacy_function($$$)
```

### `not` - Negate a Condition

Inverts the match result.

```yaml
rule:
  pattern: dangerous_operation($$$)
  not:
    inside:
      pattern: def safe_wrapper($$$): $$$
```

Matches `dangerous_operation()` NOT inside `safe_wrapper()` function.

**Combining with `has`:**
```yaml
rule:
  pattern: my_function($$$)
  not:
    has:
      pattern: safe_mode = True
```

Matches `my_function()` that does NOT have `safe_mode=True`.

### `has` - Check for Presence of Sub-Pattern

Checks if the matched node contains a specific pattern anywhere within it.

```yaml
rule:
  pattern: my_function($$$)
  has:
    pattern: debug = True
```

Matches `my_function()` calls that include `debug=True` argument.

**Order-independent argument matching:**
```yaml
rule:
  pattern: configure($$$)
  has:
    pattern: host = $HOST
  has:
    pattern: port = $PORT
```

Matches `configure()` with both host and port, regardless of argument order.

### `inside` - Check if Node Is Within Another

Checks if the matched node is nested within a specific context.

```yaml
rule:
  pattern: asyncio.sleep($$$)
  inside:
    kind: function_definition
```

Matches `asyncio.sleep()` calls inside any function.

**More specific context:**
```yaml
rule:
  pattern: asyncio.sleep($$$)
  inside:
    pattern: def test_$$$(): $$$
```

Matches `asyncio.sleep()` only inside test functions.

**Negating with `not`:**
```yaml
rule:
  pattern: asyncio.sleep($$$)
  not:
    inside:
      kind: while_statement
```

Matches `asyncio.sleep()` NOT inside while loops.

## Pattern Strictness Levels

ast-grep supports different matching strictness levels (rarely needed):

- **`smart`** (default) - Ignores whitespace, comments, and similar trivia
- **`ast`** - Abstract syntax tree matching, ignores syntactic sugar
- **`cst`** - Concrete syntax tree, exact match including whitespace
- **`relaxed`** - More flexible matching
- **`signature`** - Matches function signatures

**Example:**
```yaml
rule:
  pattern: my_function($$$)
  strictness: smart  # Default, usually not needed to specify
```

In practice, use the default `smart` matching unless you need exact whitespace matching.

## Handling Unnamed Nodes

Some AST nodes don't have named representations in the grammar (e.g., `async` keyword, decorators).

### Using `context` and `selector`

**Problem:** Can't directly match `async def` because `async` is unnamed.

**Solution:**
```yaml
# Match async function definitions
rule:
  pattern:
    context: 'async def $FUNC($$$ARGS): $$$BODY'
    selector: function_definition
```

The `context` provides the full pattern including unnamed nodes, and `selector` specifies which node type to actually match.

### Using `kind`

Match by node type instead of pattern:

```yaml
# Match all function definitions
rule:
  kind: function_definition

# Match all function definitions inside classes
rule:
  kind: function_definition
  inside:
    kind: class_definition
```

## Common Patterns by Language

### Python

```yaml
# Function definition
pattern: def $FUNC($$$PARAMS): $$$BODY

# Async function (use context/selector)
pattern:
  context: 'async def $FUNC($$$): $$$'
  selector: function_definition

# Class definition
pattern: class $CLASS($$$BASES): $$$BODY

# Method call
pattern: $OBJ.$METHOD($$$ARGS)

# Attribute access
pattern: $OBJ.$ATTR

# Import statements
pattern: import $MODULE
pattern: from $MODULE import $NAME
pattern: from $MODULE import $NAME as $ALIAS

# With statement
pattern: with $CONTEXT as $VAR: $$$BODY

# Try/except
pattern: |
  try:
    $$$TRY_BODY
  except $$$EXCEPTIONS:
    $$$EXCEPT_BODY

# List comprehension
pattern: '[$EXPR for $VAR in $ITER]'

# Dictionary comprehension
pattern: '{$KEY: $VALUE for $VAR in $ITER}'

# Lambda
pattern: lambda $$$PARAMS: $EXPR

# Decorator
pattern: '@$DECORATOR'
```

### JavaScript/TypeScript

```yaml
# Function declaration
pattern: function $NAME($$$PARAMS) { $$$BODY }

# Arrow function
pattern: ($$$PARAMS) => $$$BODY
pattern: ($$$PARAMS) => { $$$BODY }

# Method call
pattern: $OBJ.$METHOD($$$ARGS)

# Object destructuring
pattern: const { $$$PROPS } = $OBJ
pattern: const { $PROP: $VAR } = $OBJ

# Array destructuring
pattern: const [$$$ITEMS] = $ARRAY

# Import
pattern: import $NAME from $MODULE
pattern: import { $$$NAMES } from $MODULE

# Export
pattern: export const $NAME = $VALUE
pattern: export default $EXPR

# Class definition
pattern: class $NAME { $$$BODY }
pattern: class $NAME extends $PARENT { $$$BODY }

# Template literal
pattern: `$$$`

# React hooks
pattern: use$HOOK($$$)
```

### Rust

```yaml
# Function definition
pattern: fn $NAME($$$PARAMS) -> $RETURN { $$$BODY }

# Method call
pattern: $OBJ.$METHOD($$$ARGS)

# Macro invocation
pattern: $MACRO!($$$)

# Match expression
pattern: |
  match $EXPR {
    $$$ARMS
  }

# Struct definition
pattern: struct $NAME { $$$FIELDS }

# Impl block
pattern: impl $TRAIT for $TYPE { $$$ITEMS }
```

## Advanced Patterns

### Order-Independent Matching

Use `has` to match arguments regardless of order:

```yaml
rule:
  all:
    - pattern: configure($$$)
    - has: {pattern: host = $HOST}
    - has: {pattern: port = $PORT}
    - has: {pattern: protocol = $PROTO}
```

Matches `configure()` with all three arguments in any order.

### Nested Structures

```yaml
# Match nested function calls
pattern: outer($$$, inner($ARGS), $$$)

# Match chained method calls
pattern: $OBJ.$METHOD1($$$).$METHOD2($$$)
```

### Context-Aware Matching

```yaml
# Match pattern only inside specific function
rule:
  pattern: risky_operation($$$)
  inside:
    pattern: def safe_handler($$$): $$$

# Match pattern NOT inside test functions
rule:
  pattern: production_api($$$)
  not:
    inside:
      pattern: def test_$$$(): $$$
```

### Multiple Metavariables in Fix

Reuse captured metavariables in the replacement:

```yaml
rule:
  pattern: old_api($URL, $DATA, $TIMEOUT)
  fix: new_api(url=$URL, payload=$DATA, timeout=$TIMEOUT)
```

## Common Pitfalls

### Pitfall 1: Invalid Syntax

```yaml
# ❌ Not valid Python syntax
pattern: async def

# ✅ Valid complete statement
pattern: 'async def $FUNC($$$): $$$'
```

### Pitfall 2: Lowercase Metavariables

```yaml
# ❌ Invalid - lowercase not allowed
pattern: $myvar = $value

# ✅ Valid - all uppercase
pattern: $MY_VAR = $VALUE
```

### Pitfall 3: Text-Based Matching

```yaml
# ❌ Won't match comments or strings
pattern: TODO

# ✅ ast-grep matches AST nodes, not text
# Use grep for text search instead
```

### Pitfall 4: Trying to Match Unnamed Nodes

```yaml
# ❌ 'async' is unnamed in AST
pattern: async

# ✅ Use context and selector
pattern:
  context: 'async def $FUNC($$$): $$$'
  selector: function_definition
```

### Pitfall 5: Too Broad Patterns

```yaml
# ❌ Matches ALL function calls
pattern: $FUNC($$$)

# ✅ Be specific or add constraints
pattern: dangerous_function($$$)

# OR
rule:
  pattern: $FUNC($$$)
  inside:
    pattern: def risky_context($$$): $$$
```

### Pitfall 6: Comma Handling

When removing arguments, handle all positions:

```yaml
# Need multiple patterns for different comma positions
rule:
  any:
    - pattern: func($$$START, arg=$_, $$$END)
      fix: func($$$START, $$$END)
    - pattern: func(arg=$_, $$$END)
      fix: func($$$END)
    - pattern: func(arg=$_)
      fix: func()
```

## Debugging Patterns

### View AST Structure

```bash
# See how ast-grep parses a pattern
ast-grep -p 'your_pattern' --debug-query=ast

# See AST of actual code
echo 'def foo(x): return x' | ast-grep -p '$$$' --debug-query=ast
```

### Test Incrementally

```bash
# Start with broad pattern
ast-grep -p '$FUNC($$$)' -l python .

# Add constraints incrementally
ast-grep -p 'specific_function($$$)' -l python .

# Add more constraints with inline rules
ast-grep --inline-rules '
rule:
  pattern: specific_function($$$)
  not:
    has:
      pattern: safe = True
' .
```

### Use JSON Output

```bash
# Get detailed match information
ast-grep -p 'pattern' -l python src/ --json
```

## Pattern Testing Checklist

When writing patterns, test against:

1. **Different argument positions**
   - Zero arguments
   - One argument
   - Multiple arguments
   - Keyword arguments in different orders

2. **Different formatting**
   - Single line
   - Multi-line
   - With extra whitespace
   - With comments

3. **Edge cases**
   - Empty bodies
   - Nested structures
   - Similar-looking code that shouldn't match

4. **False positives**
   - Code that matches but shouldn't
   - Use `not`, `inside`, `has` to exclude

5. **False negatives**
   - Code that should match but doesn't
   - Check pattern syntax validity
   - Verify metavariable naming

## Quick Reference

### Metavariables
- `$VAR` - Single node (UPPERCASE only)
- `$$$ARGS` - Zero or more nodes
- `$_` - Anonymous (match but don't capture)

### Operators
- `all: [...]` - ALL conditions must match
- `any: [...]` - ANY condition must match
- `not: {...}` - Negate condition
- `has: {...}` - Contains pattern
- `inside: {...}` - Within context

### Node Types
- `kind: function_definition` - Match by AST node type
- `pattern: {...}` - Match by code pattern
- `context: 'code'` + `selector: kind` - Handle unnamed nodes

### Testing
```bash
# Test pattern
ast-grep -p 'pattern' -l language path/

# Debug AST
ast-grep -p 'pattern' --debug-query=ast

# JSON output
ast-grep -p 'pattern' --json
```

